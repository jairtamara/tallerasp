﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Taller_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" ");
            var random = new Random();
            Random rnd = new Random((int)DateTime.Now.Ticks);
            String[] nombres = { "juan", "pablo", "Paco", "jose", "Alberto","andres","felipe", "daniel",
            "Daniel","Maria","Paula","margot","Monica", "Marcela", "Laura"};
            String[] apellidos = { "sanchez", "perez", "lopez", "zelaya", "alvarez","alvarado","enciso","saavedra",
            "cortez", "gomez", "martinez"};
            String[] sexo = { "masculino", "femenino" };
            string[] paises = {"colombia","peru","brasil","alemania","españa", "argentina","bolivia", "mexico","panama",
            "nicaragua","uruguay", "paraguay", "chile","venezuela"};
            string[] correo = {"punk@gmail.com", "pink@gmail.com","wau@hotmail.com","back@hotmail.com","drunk@gmail.com",
                    "work@gmail.com","fuu@gmail.com","pack@hotmail.com", "salmo@itc.edu.co"};

            var listapersona = new List<Persona>();
            for (int i = 0; i <= 30; i++)
            {

                listapersona.Add(new Persona()
                {

                    nombre = nombres[rnd.Next(0, 10)],
                    apellido = apellidos[rnd.Next(0, 11)],
                    edad = random.Next(18, 100),
                    sexo = sexo[rnd.Next(0, 1)],
                    pais = paises[rnd.Next(0, 14)],
                    correo = correo[rnd.Next(0, 9)]


                });
                i++;
                listapersona.Add(new Persona()
                {
                    nombre = nombres[rnd.Next(10, 15)],
                    apellido = apellidos[rnd.Next(0, 11)],
                    edad = random.Next(18, 100),
                    sexo = sexo[rnd.Next(1, 2)],
                    pais = paises[rnd.Next(0, 14)],
                    correo = correo[rnd.Next(0, 9)]
                });
            }


            Console.WriteLine("Por Favor Ingrese UNA OPCION" + "\n \n 1:Mostrar las Personas registradad" +
               "\n \n 2.Consultar todas las mujeres del grupo" +
               "\n \n 3.Consultar sólo las personas cuyo apellido termine con la letra z y que vivan en Colombia. " +
               "\n \n 4.Consultar las personas cuya edad esté entre los 18 y los 50, ordenar los resultados por sexo, luego por apellido en forma descendente. " +
               "\n \n 5.Consultar sólo el Nombre y Apellidos de las personas del arreglo y agregarle una unidad a la edad." +
               "\n \n 6.Consultar las personas cuyo correo sea del dominio gmail.com." +
               "\n \n 7.Consultar Los hombre cuya edad supere los 20 años, que viva en Colombia, o Perú, o Venezuela y ordenarlos en orden descendente por edad y luego por nombre de forma ascendente." +
               "\n \n 8.Consultar en orden ascendente según la edad a todas las personas y tomar sólo las primeras 5 personas." +
               "\n \n 9.Contar cuántas personas tienen correo de itc.edu.co." +
               "\n \n 10.Consultar todas las personas que viven en Colombia y sólo traer el primero y último registro." +
               "\n \n 11.Consultar a las mujeres cuyo nombre inicie con “M”, su apellido termina con “z”.");
            int op = Convert.ToInt32(Console.ReadLine());

            switch (op)
            {
                case 1:
                    foreach (var item in listapersona)
                    {
                        Console.WriteLine("El nombre es: " + item.nombre + "\nEl apellido es: " + item.apellido + "\nLa edad es: " + item.edad
                            + "\nEl sexo es :" + item.sexo + "\nEl Pais es: " + item.pais + "\nEl Correo es: " + item.correo);
                        Console.WriteLine("  " + "\n   ");


                    }
                    Console.ReadKey();
                    break;
                case 2:
                    Console.WriteLine("Consultar todas las mujeres del grupo");
                    var mujergrupo = from mujerg in listapersona
                                     where mujerg.sexo.StartsWith("femenino")
                                     orderby mujerg.sexo ascending
                                     select mujerg;
                    foreach (var item in mujergrupo)
                    {
                        Console.WriteLine("Nombre:" + item.nombre + " \n apellido:" + item.apellido +
                            "\n Edad:" + item.edad + "\n Sexo:" + item.sexo + "\n Pais:" + item.pais);
                    }

                    break;

                case 3:
                    Console.WriteLine("Consultar sólo las personas cuyo apellido termine con la letra z y que vivan en Colombia.");
                    var mujeresz = from mujer in listapersona
                                   where mujer.apellido.EndsWith("z") && mujer.sexo.StartsWith("femenino") && mujer.pais.StartsWith("colombia")
                                   orderby mujer.apellido ascending
                                   select mujer;

                    foreach (var item in mujeresz)
                    {
                        Console.WriteLine("Nombre:" + item.nombre + " \n apellido:" + item.apellido +
                            "\n Edad:" + item.edad + "\n Sexo:" + item.sexo + "\n Pais:" + item.pais);
                    }
                    Console.ReadKey();
                    break;

                case 4:
                    Console.WriteLine("Consultar las personas cuya edad esté entre los 18 y los 50, ordenar los resultados por sexo, luego por apellido en forma descendente.");
                    var rangoedad = from rangoed in listapersona
                                    where rangoed.edad > 18 && rangoed.edad < 50
                                    orderby rangoed.sexo, rangoed.apellido descending
                                    select rangoed;
                    foreach (var item in rangoedad)
                    {
                        Console.WriteLine("sexo:  " + item.sexo + "\n Apellido:  " + item.apellido + "\n Edad:  " + item.edad);
                        Console.ReadKey();
                    }

                    break;

                case 5:

                    foreach (var item in listapersona)
                    {
                        Console.WriteLine("Consultar sólo el Nombre y Apellidos de las personas del arreglo y agregarle una unidad a la edad.");
                        item.aumentarEdad();
                        Console.WriteLine("Nombre:  " + item.nombre + "\n Apellido:  " + item.apellido + "\n Edad:  " + item.edad);
                        Console.ReadKey();
                    }

                    break;

                case 6:
                    Console.WriteLine("Consultar las personas cuyo correo sea del dominio gmail.com.");
                    var correos = from gmail in listapersona
                                  where gmail.correo.EndsWith("gmail.com")
                                  orderby gmail.nombre ascending
                                  select gmail;
                    foreach (var item in correos)
                    {
                        Console.WriteLine("Nombre:  " + item.nombre + "\n Correo:  " + item.correo);

                    }
                    Console.ReadKey();

                    break;
                case 7:
                    Console.WriteLine("Edad mayor a 20 pais colombia, peru o venezuela");
                    var mix = from edpa in listapersona
                              where edpa.edad > 20 && edpa.pais.StartsWith("colombia") || edpa.pais.StartsWith("peru") || edpa.pais.StartsWith("venezuela")
                              orderby edpa.edad descending
                              select edpa;
                    foreach (var item in mix)
                    {
                        Console.WriteLine("Nombre:  " + item.nombre + "\n Pais:  " + item.pais + "\n Edad:  " + item.edad);
                        Console.ReadKey();

                    }

                    Console.WriteLine("Consultar Los hombre cuya edad supere los 20 años, que viva en Colombia, o Perú, o Venezuela y ordenarlos en orden descendente por edad y luego por nombre de forma ascendente.");
                    var mux = from edpa in listapersona
                              where edpa.edad > 20 && edpa.pais.StartsWith("colombia") || edpa.pais.StartsWith("peru") || edpa.pais.StartsWith("venezuela")
                              orderby edpa.nombre ascending
                              select edpa;
                    foreach (var item in mux)
                    {
                        Console.WriteLine("Nombre:  " + item.nombre + "\n Pais:  " + item.pais + "\n Edad:  " + item.edad);
                        Console.ReadKey();

                    }

                    break;
                case 8:
                    Console.WriteLine("Consultar en orden ascendente según la edad a todas las personas y tomar sólo las primeras 5 personas.");
                    var eda = from edp in listapersona

                              orderby edp.edad ascending

                              select edp;

                    foreach (var item in eda.Take(5))
                    {
                        Console.WriteLine(item.nombre);
                        Console.ReadKey();
                    }
                    break;

                case 9:
                    Console.WriteLine("Contar cuántas personas tienen correo de itc.edu.co.");
                    var itc = from coritc in listapersona
                              where coritc.correo.EndsWith("itc.edu.co")
                              orderby coritc.correo ascending
                              select coritc;

                    foreach (var item in itc)
                    {
                        Console.WriteLine("Nombre:  " + item.nombre + " Correo:  " + item.correo);

                    }
                    Console.ReadKey();
                    break;

                case 10:

                    Console.WriteLine("Consultar todas las personas que viven en Colombia y sólo traer el primero y último registro. ");
                    var percol = from col in listapersona
                                 where col.pais.StartsWith("colombia")
                                 orderby col.nombre ascending
                                 select col;
                    foreach (var item in percol.Take(1))
                    {
                        Console.WriteLine("Nombre:  " + item.nombre + "  Pais:  " + item.pais);
                        Console.ReadKey();
                    }

                    break;

                case 11:
                    Console.WriteLine(" Consultar a las mujeres cuyo nombre inicie con “M”, su apellido termina con “z”. ");
                    var mujermz = from muj in listapersona
                                  where muj.nombre.StartsWith("m") && muj.apellido.EndsWith("z")
                                  orderby muj.nombre ascending
                                  select muj;
                    foreach (var item in mujermz)
                    {
                        Console.WriteLine("Nombre:  " + item.nombre + "\n Apellido:" + item.apellido);
                        Console.ReadKey();
                    }

                    break;



                default:
                    Console.WriteLine("Opcion invalida");
                    break;

            }



        }
    }
}
