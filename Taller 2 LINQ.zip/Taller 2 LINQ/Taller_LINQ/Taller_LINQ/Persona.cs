﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taller_LINQ
{
    class Persona
    {
        public string nombre { get; set; }
        public string apellido { get; set; }
        public int edad { get; set; }
        public string sexo { get; set; }
        public string pais { get; set; }
        public string correo { get; set; }


        public void aumentarEdad()
        {
            this.edad++;
        }
        public void promedio(int a, int b)
        {
            Console.WriteLine(a / b);
        }

    }
}
